package com.example.caseywhite_c196;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class EditCourseFragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_edit_course, container, false);

        final EditText courseNameTF = view.findViewById(R.id.courseNameTF2);
        courseNameTF.setText(RecyclerViewAdapter2.selectedCourse.getName());
        final EditText courseStartDate = view.findViewById(R.id.courseStartDateTF2);
        courseStartDate.setText(RecyclerViewAdapter2.selectedCourse.getStartDate());
        final EditText courseEndDate = view.findViewById(R.id.courseEndDateTF2);
        courseEndDate.setText(RecyclerViewAdapter2.selectedCourse.getEndDate());
        final EditText courseMentorName = view.findViewById(R.id.courseMentorNameTF2);
        courseMentorName.setText(RecyclerViewAdapter2.selectedCourse.getMentorName());
        final EditText courseMentorPhone = view.findViewById(R.id.courseMentorPhoneTF2);
        courseMentorPhone.setText(RecyclerViewAdapter2.selectedCourse.getMentorPhone());
        final EditText courseMentorEmail = view.findViewById(R.id.courseMentorEmailTF2);
        courseMentorEmail.setText(RecyclerViewAdapter2.selectedCourse.getMentorEmail());

        Button submitButton = view.findViewById(R.id.submitAddCourseButton2);
        submitButton.setOnClickListener(v -> {
            MainActivity.DBHelper.updateCoursesData(
                    RecyclerViewAdapter2.selectedCourse.getCourseID(),
                    RecyclerViewAdapter2.selectedCourse.getTermID(),
                    courseNameTF.getText().toString(),
                    courseStartDate.getText().toString(),
                    courseEndDate.getText().toString(),
                    RecyclerViewAdapter2.selectedCourse.getStatus(),
                    courseMentorName.getText().toString(),
                    courseMentorPhone.getText().toString(),
                    courseMentorEmail.getText().toString(),
                    RecyclerViewAdapter2.selectedCourse.getAlert(),
                    RecyclerViewAdapter2.selectedCourse.getNotes()
            );
            //Navigation.findNavController(v).navigate(R.id.action_editCourseFragment_to_courseDetailFragment);
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        return view;
    }
}
