package com.example.caseywhite_c196.Skeleton;

import java.util.ArrayList;

public class Terms {

    private int termId;
    private String name;
    private String startDate;
    private String endDate;
    private int active;

    public static ArrayList<Terms> termsList = new ArrayList<>();

    public Terms(int termId, String name, String startDate, String endDate, int active) {
        this.termId = termId;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.active = active;
    }

    public int getTermId() { return termId; }
    public void setTermId(int termId) { this.termId = termId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public int getActive() { return active; }
    public void setActive(int active) { this.active = active; }

    public void addTerm(Terms term) { termsList.add(term); }
    public ArrayList<Terms> getTermsList() { return termsList; }
    public static void clearList() { termsList.clear(); }

}
