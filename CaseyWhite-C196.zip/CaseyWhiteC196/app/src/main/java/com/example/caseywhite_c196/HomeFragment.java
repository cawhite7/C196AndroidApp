package com.example.caseywhite_c196;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

public class HomeFragment extends Fragment {

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        View viewHome = inflater.inflate(R.layout.fragment_home, container, false);

        TextView progress = viewHome.findViewById(R.id.progressTV);
        double progressF = ((double) MainActivity.DBHelper.getCompletedCourses() / (double) MainActivity.DBHelper.getInStatusCourses()) * 100.0;
        int progressN = (int) progressF;
        String progressFormat = progressN + "%";
        progress.setText(progressFormat);

        return viewHome;
    }

    public void onViewCreated(@NonNull final View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.currentTermButton).setOnClickListener(v -> {
            RecyclerViewAdapter.selectedTerm = MainActivity.DBHelper.getCurrentTerm();
            if (RecyclerViewAdapter.selectedTerm != null) {
                Navigation.findNavController(v).navigate(R.id.action_homeFragment_to_termDetailFragment);
            } else {
                Toast.makeText(getActivity(), "No Active Terms", Toast.LENGTH_LONG).show();
            }
        });

        view.findViewById(R.id.allTermsButton).setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_FirstFragment_to_allTermsFragment));

    }

}
