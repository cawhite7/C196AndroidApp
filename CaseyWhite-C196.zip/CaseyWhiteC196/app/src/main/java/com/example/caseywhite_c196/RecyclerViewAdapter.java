package com.example.caseywhite_c196;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.caseywhite_c196.Skeleton.Terms;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    public static Terms selectedTerm = null;

    RecyclerViewAdapter() {
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Terms term = Terms.termsList.get(position);

        String dateComb = term.getStartDate() + " to " + term.getEndDate();

        holder.termNameTV.setText(term.getName());
        holder.dateTV.setText(dateComb);

        holder.parentLayout.setOnClickListener(v -> {
            selectedTerm = Terms.termsList.get(position);
            Navigation.findNavController(v).navigate(R.id.action_allTermsFragment_to_termDetailFragment);
        });

    }

    @Override
    public int getItemCount() {
        return Terms.termsList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView termNameTV;
        TextView dateTV;
        RelativeLayout parentLayout;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            termNameTV = itemView.findViewById(R.id.termNameTextView);
            dateTV = itemView.findViewById(R.id.dateTextView);
            parentLayout = itemView.findViewById(R.id.recycler_constraint);
        }
    }
}
