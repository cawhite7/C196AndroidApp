package com.example.caseywhite_c196;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.caseywhite_c196.Skeleton.Assessments;

public class RecyclerViewAdapter3 extends RecyclerView.Adapter<RecyclerViewAdapter3.ViewHolder>{

    static Assessments selectedAssessment = null;

    RecyclerViewAdapter3() {
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Assessments assessment = Assessments.getAssessmentsList().get(position);

        String dateComb = "Goal Date: " + assessment.getAssessmentGoal();

        holder.assessmentN.setText(assessment.getName());
        holder.goalD.setText(dateComb);

        holder.parentLayout.setOnClickListener(v -> {
            selectedAssessment = Assessments.getAssessmentsList().get(position);
            Navigation.findNavController(v).navigate(R.id.action_assessmentsFragment_to_assessmentDetailFragment);
        });
    }

    @Override
    public int getItemCount() {
        return Assessments.getAssessmentsList().size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView assessmentN;
        TextView goalD;
        RelativeLayout parentLayout;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            assessmentN = itemView.findViewById(R.id.termNameTextView);
            goalD = itemView.findViewById(R.id.dateTextView);
            parentLayout = itemView.findViewById(R.id.recycler_constraint);
        }
    }

}