package com.example.caseywhite_c196;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import java.util.Objects;

public class AddCourseFragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_course, container, false);

        final EditText courseNameTF = view.findViewById(R.id.courseNameTF);
        final EditText courseStartDateTF = view.findViewById(R.id.courseStartDateTF);
        courseStartDateTF.setText(RecyclerViewAdapter.selectedTerm.getStartDate());
        final EditText courseEndDateTF = view.findViewById(R.id.courseEndDateTF);
        courseEndDateTF.setText(RecyclerViewAdapter.selectedTerm.getEndDate());
        final EditText courseMentorNameTF = view.findViewById(R.id.courseMentorNameTF);
        final EditText courseMentorPhoneTF = view.findViewById(R.id.courseMentorPhoneTF);
        final EditText courseMentorEmailTF = view.findViewById(R.id.courseMentorEmailTF);
        final EditText courseAssessmentGoalDateTF = view.findViewById(R.id.courseAssessmentGoalDateTF);
        courseAssessmentGoalDateTF.setText(RecyclerViewAdapter.selectedTerm.getEndDate());

        Button submitAddCourseButton = view.findViewById(R.id.submitAddCourseButton);
        submitAddCourseButton.setOnClickListener(v -> {
            MainActivity.DBHelper.insertCourseData(
                    RecyclerViewAdapter.selectedTerm.getTermId(),
                    courseNameTF.getText().toString(),
                    courseStartDateTF.getText().toString(),
                    courseEndDateTF.getText().toString(),
                    "Plan to Take",
                    courseMentorNameTF.getText().toString(),
                    courseMentorPhoneTF.getText().toString(),
                    courseMentorEmailTF.getText().toString(),
                    0,
                    "Notes"
            );
            //Navigation.findNavController(v).navigate(R.id.action_addCourseFragment_to_termCoursesFragment);
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        return view;
    }
}
