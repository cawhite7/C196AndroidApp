package com.example.caseywhite_c196;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;

import com.example.caseywhite_c196.DataManagement.DBHelper;
import com.example.caseywhite_c196.Skeleton.Courses;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.text.Layout;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.Objects;
import java.util.function.ToLongBiFunction;

public class MainActivity extends AppCompatActivity {

    public static DBHelper DBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setSubtitle("WGU Term Assistant");
        setSupportActionBar(toolbar);

        DBHelper = new DBHelper(this);

        if (!DBHelper.checkForData()) genData();

        DBHelper.genTermsData();
        DBHelper.genCoursesData();
        DBHelper.genAssessmentData();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

            if (id == R.id.homeNav) {
                NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
                navController.navigate(R.id.homeFragment);
            }

            if (id == R.id.currentTermNav) {
                RecyclerViewAdapter.selectedTerm = MainActivity.DBHelper.getCurrentTerm();
                if (RecyclerViewAdapter.selectedTerm != null) {
                    NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
                    navController.navigate(R.id.termDetailFragment);
                } else {
                    Toast.makeText(this, "No Active Terms", Toast.LENGTH_LONG).show();
                }
            }

            if (id == R.id.allTermsNav) {
                NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
                navController.navigate(R.id.allTermsFragment);
            }

            if (id == R.id.addNewTermNavigation) {
                NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
                navController.navigate(R.id.addTermFragment);
            }

        return super.onOptionsItemSelected(item);
    }

    private void genNotification(int id) {

        if (id == 1) {
            final String CHANNEL_1 = "Channel1";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel1 = new NotificationChannel(
                        CHANNEL_1,
                        "Channel 1",
                        NotificationManager.IMPORTANCE_HIGH
                );
                channel1.setDescription("Channel 1");

                NotificationManager manager = getSystemService(NotificationManager.class);
                assert manager != null;
                manager.createNotificationChannel(channel1);
            }

            for (Courses course : DBHelper.getCourseCurrentTerm()) {
                String courseDates = course.getName() + ": " + course.getStartDate() + " to " + course.getEndDate();
                Notification notification = new NotificationCompat.Builder(this, CHANNEL_1)
                        .setSmallIcon(R.mipmap.ic_launcher_round)
                        .setContentTitle("Start and End Date for each course")
                        .setContentText(courseDates)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(courseDates))
                        .setPriority(NotificationCompat.PRIORITY_MAX)
                        .setAutoCancel(true)
                        .build();
                NotificationManagerCompat.from(this).notify(course.getCourseID(), notification);
            }

        } else {
            final String CHANNEL_1 = "Channel1";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel1 = new NotificationChannel(
                        CHANNEL_1,
                        "Channel 1",
                        NotificationManager.IMPORTANCE_HIGH
                );
                channel1.setDescription("Channel 1");

                NotificationManager manager = getSystemService(NotificationManager.class);
                assert manager != null;
                manager.createNotificationChannel(channel1);
            }

            for (Courses course : DBHelper.getCourseCurrentTerm()) {
                String assessmentGoals = course.getName() + "(" +
                        DBHelper.getAssessmentNameByCourse(course.getCourseID()) +
                        "): " + "Goal date " + DBHelper.getAssessmentGoalByCourse(course.getCourseID());
                Notification notification2 = new NotificationCompat.Builder(this, CHANNEL_1)
                        .setSmallIcon(R.mipmap.ic_launcher_round)
                        .setContentTitle("Assessment Goal Alert")
                        .setContentText(assessmentGoals)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(assessmentGoals))
                        .setPriority(NotificationCompat.PRIORITY_MAX)
                        .setAutoCancel(true)
                        .build();

                NotificationManagerCompat.from(this).notify(course.getCourseID(), notification2);
            }

        }

    }

    private void genData() {
        DBHelper.insertTermData(
                "Spring 2020",
                "2020-01-01",
                "2020-06-30",
                1
        );
        DBHelper.insertTermData(
                "Fall 2020",
                "2020-07-01",
                "2020-12-31",
                0
        );
        DBHelper.insertTermData(
                "Spring 2021",
                "2021-01-01",
                "2021-06-30",
                0
        );
        DBHelper.insertTermData(
                "Fall 2021",
                "2021-07-01",
                "2021-12-31",
                0
        );
        DBHelper.insertTermData(
                "Spring 2022",
                "2022-01-01",
                "2022-06-30",
                0
        );
        DBHelper.insertTermData(
                "Fall 2022",
                "2022-07-01",
                "2022-12-31",
                0
        );
        DBHelper.insertTermData(
                "Spring 2023",
                "2023-01-01",
                "2023-06-30",
                0
        );
        DBHelper.insertTermData(
                "Fall 2023",
                "2023-07-01",
                "2023-12-31",
                0
        );
        DBHelper.insertCourseData(
                1,
                "Introduction to IT - C182",
                "2020-01-01",
                "2020-02-14",
                "Completed",
                "Julio Markez",
                "(912) 123-0232",
                "j.markez@wgu.edu",
                0,
                "Notes"
        );
        DBHelper.insertAssessmentData(
                1,
                "OA: Introduction to IT",
                "Introduction to IT examines information technology as a " +
                        "discipline and the various roles and functions of the IT department " +
                        "as business support. Students are presented with various IT disciplines " +
                        "including systems and services, network and security, scripting and programming, " +
                        "data management, and business of IT, with a survey of technologies in every area " +
                        "and how they relate to each other and to the business.",
                "2020-01-31"
        );
        DBHelper.insertCourseData(
                1,
                "Critical Thinking and Logic - C168",
                "2020-02-15",
                "2020-03-31",
                "In Progress",
                "Julio Markez",
                "(912) 123-0232",
                "j.markez@wgu.edu",
                0,
                "Notes"
        );
        DBHelper.insertAssessmentData(
                2,
                "OA: Critical Thinking and Logic",
                "The graduate analyzes open-ended problems by learning about the problem " +
                        "and evaluating the accuracy and relevance of different perspectives on the problem.",
                "2020-03-15"
        );
        DBHelper.insertCourseData(
                2,
                "Scripting and Programming - Foundations - C173",
                "2020-07-01",
                "2020-08-15",
                "Plan to Take",
                "Julio Markez",
                "(912) 123-0232",
                "j.markez@wgu.edu",
                0,
                "Notes"
        );
        DBHelper.insertAssessmentData(
                3,
                "OA: Scripting and Programming - Foundations",
                "Scripting and Programming - Foundations provides an introduction to programming, " +
                        "covering basic elements such as variables, data types, flow control, and design concepts." +
                        " The course is language-agnostic in nature, ending in a survey of languages and introduces" +
                        " the distinction between interpreted and compiled languages. There are no prerequisites for" +
                        " this course.",
                "2020-08-02"
        );
    }

}