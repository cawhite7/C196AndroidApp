package com.example.caseywhite_c196.DataManagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.caseywhite_c196.RecyclerViewAdapter;
import com.example.caseywhite_c196.RecyclerViewAdapter2;
import com.example.caseywhite_c196.Skeleton.Assessments;
import com.example.caseywhite_c196.Skeleton.Courses;
import com.example.caseywhite_c196.Skeleton.Terms;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "wgu.db";
    private static final int DB_VERSION = 1;

    private static final String TERM_TABLE = "termTable";

    private static final String TERM_TERMID_COL = "TermID";
    private static final String TERM_NAME_COL = "Name";
    private static final String TERM_STARTDATE_COL = "StartDate";
    private static final String TERM_ENDATE_COL = "EndDate";
    private static final String TERM_ACTIVE_COL = "Active";

    private static final String COURSE_TABLE = "courseTable";

    public static final String COURSE_COURSEID_COL = "CourseID";
    private static final String COURSE_TERMID_COL = "TermID";
    private static final String COURSE_NAME_COL = "Name";
    private static final String COURSE_STARTDATE_COL = "StartDate";
    private static final String COURSE_ENDDATE_COL = "EndDate";
    private static final String COURSE_STATUS_COL = "Status";
    private static final String COURSE_MENTORNAME_COL = "MentorName";
    private static final String COURSE_MENTORPHONE_COL = "MentorPhone";
    private static final String COURSE_MENTEREMAIL_COL = "MentorEmail";
    private static final String COURSE_ALERTS_COL = "Alerts";
    private static final String NOTES = "Notes";

    private static final String ASSESSMENT_TABLE = "assessmentTable";

    public static final String ASSESSMENT_ASSESSMENTID_COL = "AssessmentID";
    private static final String ASSESSMENT_COURSEID_COL = "CourseID";
    private static final String ASSESSMENT_NAME_COL = "Name";
    private static final String ASSESSMENT_DESC_COL = "Description";
    private static final String ASSESSMENT_ASSESSMENTGOAL_COL = "Goal";



    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table if not exists " + TERM_TABLE +
                " (TermID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "Name TEXT," +
                "StartDate TEXT," +
                "EndDate TEXT," +
                "Active INTEGER)");
        db.execSQL("create table if not exists " + COURSE_TABLE +
                " (CourseID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "TermID INTEGER," +
                "Name TEXT," +
                "StartDate TEXT," +
                "EndDate TEXT," +
                "Status TEXT," +
                "MentorName TEXT," +
                "MentorPhone TEXT," +
                "MentorEmail TEXT," +
                "Alerts INTEGER," +
                "Notes TEXT," +
                "FOREIGN KEY(TermID) REFERENCES termTable(TermID))");
        db.execSQL("create table if not exists " + ASSESSMENT_TABLE +
                " (AssessmentID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "CourseID INTEGER," +
                "Name TEXT," +
                "Description TEXT," +
                "GOAL TEXT," +
                "FOREIGN KEY(CourseID) REFERENCES courseTable(CourseID))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TERM_TABLE);
        db.execSQL("drop table if exists " + COURSE_TABLE);
        db.execSQL("drop table if exists " + ASSESSMENT_TABLE);
        onCreate(db);
    }

    public void insertTermData(String name, String startDate, String endDate, int active) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TERM_NAME_COL,name);
        contentValues.put(TERM_STARTDATE_COL,startDate);
        contentValues.put(TERM_ENDATE_COL,endDate);
        contentValues.put(TERM_ACTIVE_COL,active);
        db.insert(TERM_TABLE, null, contentValues);
        db.close();
    }

    public void insertCourseData(
            int termID,
            String name,
            String startDate,
            String endDate,
            String status,
            String mentorName,
            String mentorPhone,
            String mentorEmail,
            int alerts,
            String notes
    ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COURSE_TERMID_COL,termID);
        contentValues.put(COURSE_NAME_COL,name);
        contentValues.put(COURSE_STARTDATE_COL,startDate);
        contentValues.put(COURSE_ENDDATE_COL,endDate);
        contentValues.put(COURSE_STATUS_COL,status);
        contentValues.put(COURSE_MENTORNAME_COL,mentorName);
        contentValues.put(COURSE_MENTORPHONE_COL,mentorPhone);
        contentValues.put(COURSE_MENTEREMAIL_COL,mentorEmail);
        contentValues.put(COURSE_ALERTS_COL,alerts);
        contentValues.put(NOTES,notes);
        db.insert(COURSE_TABLE, null, contentValues);
        db.close();
    }

    public void insertAssessmentData(
            int courseID,
            String name,
            String description,
            String goal
    ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ASSESSMENT_COURSEID_COL,courseID);
        contentValues.put(ASSESSMENT_NAME_COL,name);
        contentValues.put(ASSESSMENT_DESC_COL,description);
        contentValues.put(ASSESSMENT_ASSESSMENTGOAL_COL,goal);
        db.insert(ASSESSMENT_TABLE, null, contentValues);
        db.close();
    }

    public void genTermsData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TERM_TABLE, null);
        while (cursor.moveToNext()) {
            Terms.termsList.add(
            new Terms(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getInt(4)
            ));
        }
        cursor.close();
    }

    public void genAssessmentData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + ASSESSMENT_TABLE, null);
        while (cursor.moveToNext()) {
            Assessments.addAssessment(
                    new Assessments(
                            cursor.getInt(0),
                            cursor.getInt(1),
                            cursor.getString(2),
                            cursor.getString(3),
                            cursor.getString(4)
                    )
            );
        }
        cursor.close();
    }

    public void genAssessmentDataByCourse() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + ASSESSMENT_TABLE + " where CourseID=" + RecyclerViewAdapter2.selectedCourse.getCourseID(), null);
        while (cursor.moveToNext()) {
            Assessments.addAssessment(
                    new Assessments(
                            cursor.getInt(0),
                            cursor.getInt(1),
                            cursor.getString(2),
                            cursor.getString(3),
                            cursor.getString(4)
                    )
            );
        }
        cursor.close();
    }

    public boolean checkForData() {
        boolean returnValue;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TERM_TABLE, null);
        returnValue = cursor.getCount() > 0;
        cursor.close();
        return returnValue;
    }

    public boolean checkTermDependency(int id) {
        boolean returnValue;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select CourseID from " + COURSE_TABLE + " where TermID=" + id, null);
        returnValue = cursor.getCount() > 0;
        cursor.close();
        return returnValue;
    }

    public boolean checkCourseDependency(int id) {
        boolean returnValue;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select AssessmentID from " + ASSESSMENT_TABLE + " where CourseID=" + id, null);
        returnValue = cursor.getCount() > 0;
        cursor.close();
        return returnValue;
    }

    public boolean checkActiveTerm() {
        boolean returnValue;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TERM_TABLE + " where Active=1", null);
        returnValue = cursor.getCount() > 0;
        cursor.close();
        return returnValue;
    }

    public void genCoursesData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + COURSE_TABLE, null);
        while (cursor.moveToNext()) {
            Courses.addCourse(
                    new Courses(
                            cursor.getInt(0),
                            cursor.getInt(1),
                            cursor.getString(2),
                            cursor.getString(3),
                            cursor.getString(4),
                            cursor.getString(5),
                            cursor.getString(6),
                            cursor.getString(7),
                            cursor.getString(8),
                            cursor.getInt(9),
                            cursor.getString(10)
                    ));
        }
        cursor.close();
    }

    public String getAssessmentName(int id) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Name from " + ASSESSMENT_TABLE + " where AssessmentID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(0);
        }
        cursor.close();
        return returnValue;
    }

    public String getMentorName(int id) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select MentorName from " + COURSE_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(0);
        }
        cursor.close();
        return returnValue;
    }

    public String getMentorPhone(int id) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select MentorPhone from " + COURSE_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(0);
        }
        cursor.close();
        return returnValue;
    }

    public String getMentorEmail(int id) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select MentorEmail from " + COURSE_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(0);
        }
        cursor.close();
        return returnValue;
    }

    public String getAssessmentNameByCourse(int id) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Name from " + ASSESSMENT_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(0);
        }
        cursor.close();
        return returnValue;
    }

    public String getAssessmentGoal(int id) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Goal from " + ASSESSMENT_TABLE + " where AssessmentID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(0);
        }
        cursor.close();
        return returnValue;
    }

    public ArrayList<String> getAssessmentGoalsForCourse(int id) {
        ArrayList<String> returnValue = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Name,Goal from " + ASSESSMENT_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            String temp = cursor.getString(1) + " " + cursor.getString(0);
            returnValue.add(temp);
        }
        cursor.close();
        return returnValue;
    }

    public int getAssessmentGoalIdByName(String name) {
        int returnValue = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select AssessmentID from " + ASSESSMENT_TABLE + " where Name=" + name, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getInt(0);
        }
        cursor.close();
        return returnValue;
    }

    public ArrayList<String> getAssessmentGoalByCourse(int id) {
        ArrayList<String> returnValue = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Name,Goal from " + ASSESSMENT_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue.add(cursor.getString(1) + cursor.getString(0) + " Goal Date!");
        }
        cursor.close();
        return returnValue;
    }

    public String getCourseStartDate(int id) {
        String returnValue = "Failed";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Name,StartDate from " + COURSE_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(1) + " " + cursor.getString(0) + " Start Date!";
        }
        cursor.close();
        return returnValue;
    }

    public String getCourseEndDate(int id) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Name,EndDate from " + COURSE_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(1) + " " + cursor.getString(0) + " End Date!";
        }
        cursor.close();
        return returnValue;
    }

    public int getInStatusCourses() {
        int returnValue = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + COURSE_TABLE + " where Status IN ('Plan to Take', 'Completed', 'In Progress')", null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getCount();
        }
        cursor.close();
        return returnValue;
    }

    public int getCompletedCourses() {
        int returnValue = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + COURSE_TABLE + " where Status='Completed'", null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getCount();
        }
        cursor.close();
        return returnValue;
    }

    public String getAssessmentDesc(int id) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Description from " + ASSESSMENT_TABLE + " where AssessmentID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(0);
        }
        cursor.close();
        return returnValue;
    }

    public void genCoursesDataByTerm() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + COURSE_TABLE + " where TermID=" + RecyclerViewAdapter.selectedTerm.getTermId(), null);
        while (cursor.moveToNext()) {
            Courses.addCourse(
            new Courses(
                    cursor.getInt(0),
                    cursor.getInt(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getString(6),
                    cursor.getString(7),
                    cursor.getString(8),
                    cursor.getInt(9),
                    cursor.getString(10)
            ));
        }
        cursor.close();
    }

    public String getNotes(int id) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Notes from " + COURSE_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            returnValue = cursor.getString(0);
        }
        cursor.close();
        return returnValue;
    }

    public Terms getCurrentTerm() {
        int termId = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select TermID,Active from " + TERM_TABLE + " where Active=" + 1, null);
        while (cursor.moveToNext()) {
            termId = cursor.getInt(0);
        }
        for (Terms term : Terms.termsList) {
            if (term.getTermId() == termId) return term;
        }
        cursor.close();
        return null;
    }

    public boolean checkCurrentTerm() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select TermID from " + TERM_TABLE + " where Active=" + 1, null);
        boolean returnValue = cursor.getCount() > 0 ;
        cursor.close();
        return returnValue;
    }

    public ArrayList<Courses> getCourseCurrentTerm() {
        ArrayList<Courses> returnValue = new ArrayList<>();
        ArrayList<Integer> returnSQLValues = new ArrayList<>();
        int currentTermID = getCurrentTerm().getTermId();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select CourseID from " + COURSE_TABLE + " where TermID=" + currentTermID + " AND Alerts=1", null);
        while (cursor.moveToNext()) {
            returnSQLValues.add(cursor.getInt(0));
        }
        for (Integer courseID : returnSQLValues) {
            for (Courses course : Courses.getCoursesList()) {
                if (course.getCourseID() == courseID) returnValue.add(course);
            }
        }
        cursor.close();
        return returnValue;
    }

    public String getCourseInfo(int id, int item) {
        String returnValue = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Name,StartDate,EndDate,Status,Alerts from " + COURSE_TABLE + " where CourseID=" + id, null);
        while (cursor.moveToNext()) {
            switch (item) {
                case 0:
                    returnValue = cursor.getString(0);
                    break;
                case 1:
                    returnValue = cursor.getString(1);
                    break;
                case 2:
                    returnValue = cursor.getString(2);
                    break;
                case 3:
                    returnValue = cursor.getString(3);
                    break;
                case 4:
                    int value = cursor.getInt(4);
                    if (value == 0) {
                        returnValue = "Off";
                    }
                    else if (value == 1) {
                        returnValue = "On";
                    }
                    break;
            }
        }
        cursor.close();
        return returnValue;
    }


    public void updateTermsData(int id, String name, String startDate, String endDate, int active) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TERM_TERMID_COL,id);
        contentValues.put(TERM_NAME_COL,name);
        contentValues.put(TERM_STARTDATE_COL,startDate);
        contentValues.put(TERM_ENDATE_COL,endDate);
        contentValues.put(TERM_ACTIVE_COL,active);
        db.update(TERM_TABLE, contentValues, "TermID = ?", new String[] {String.valueOf(id)});
    }

    public void updateCoursesData(
            int courseID,
            int termID,
            String name,
            String startDate,
            String endDate,
            String status,
            String mentorName,
            String mentorPhone,
            String mentorEmail,
            int alerts,
            String notes
    ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COURSE_TERMID_COL,termID);
        contentValues.put(COURSE_NAME_COL,name);
        contentValues.put(COURSE_STARTDATE_COL,startDate);
        contentValues.put(COURSE_ENDDATE_COL,endDate);
        contentValues.put(COURSE_STATUS_COL,status);
        contentValues.put(COURSE_MENTORNAME_COL,mentorName);
        contentValues.put(COURSE_MENTORPHONE_COL,mentorPhone);
        contentValues.put(COURSE_MENTEREMAIL_COL,mentorEmail);
        contentValues.put(COURSE_ALERTS_COL,alerts);
        contentValues.put(NOTES,notes);
        db.update(COURSE_TABLE, contentValues, "CourseID = ?", new String[] {String.valueOf(courseID)});
    }

    public void updateAssessmentsData(
            int assessmentID,
            int courseID,
            String name,
            String description,
            String goal
    ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ASSESSMENT_COURSEID_COL,courseID);
        contentValues.put(ASSESSMENT_NAME_COL,name);
        contentValues.put(ASSESSMENT_DESC_COL,description);
        contentValues.put(ASSESSMENT_ASSESSMENTGOAL_COL,goal);
        db.update(ASSESSMENT_TABLE, contentValues, "AssessmentID = ?", new String[] {String.valueOf(assessmentID)});
    }

    public void updateNotes(String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NOTES,notes);
        db.update(COURSE_TABLE, contentValues, "CourseID = ?", new String[] {String.valueOf(RecyclerViewAdapter2.selectedCourse.getCourseID())});
    }

    public void updateStatus(String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COURSE_STATUS_COL,status);
        db.update(COURSE_TABLE, contentValues, "CourseID = ?", new String[] {String.valueOf(RecyclerViewAdapter2.selectedCourse.getCourseID())});
    }

    public void updateAlert(String alert) {
        int alertInt = 0;
        if (alert.equals("On")) alertInt = 1;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COURSE_ALERTS_COL,alertInt);
        db.update(COURSE_TABLE, contentValues, "CourseID = ?", new String[] {String.valueOf(RecyclerViewAdapter2.selectedCourse.getCourseID())});
    }

    public void deleteTermsData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TERM_TABLE, "TermID = ?", new String[]{String.valueOf(id)});
    }

    public void deleteCoursesData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(COURSE_TABLE, "CourseID = ?", new String[]{String.valueOf(id)});
    }

    public void deleteAssessmentsData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(ASSESSMENT_TABLE, "AssessmentID = ?", new String[]{String.valueOf(id)});
    }

}