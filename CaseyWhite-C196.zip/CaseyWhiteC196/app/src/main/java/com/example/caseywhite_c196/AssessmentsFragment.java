package com.example.caseywhite_c196;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.caseywhite_c196.Skeleton.Assessments;

public class AssessmentsFragment extends Fragment {

    private RecyclerView recyclerView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_assessments, container, false);

        recyclerView = view.findViewById(R.id.assessment_recycler);
        initRecyclerView();

        TextView courseName = view.findViewById(R.id.assessmentCourseNameTV);
        courseName.setText(RecyclerViewAdapter2.selectedCourse.getName());

        Button addAssessmentButton = view.findViewById(R.id.addAssessmentButton);
        addAssessmentButton.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_assessmentsFragment_to_assessmentAddFragment));

        return view;
    }

    private void initRecyclerView() {
        RecyclerViewAdapter3 adapter = new RecyclerViewAdapter3();
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Assessments.clearList();
        MainActivity.DBHelper.genAssessmentDataByCourse();
    }

}
