package com.example.caseywhite_c196;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class AssessmentEditFragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_assessment_edit, container, false);

        final EditText assessmentName = view.findViewById(R.id.editAssessmentNameTF);
        assessmentName.setText(RecyclerViewAdapter3.selectedAssessment.getName());
        final EditText assessmentGoal = view.findViewById(R.id.editAssessmentGoalTF);
        assessmentGoal.setText(RecyclerViewAdapter3.selectedAssessment.getAssessmentGoal());
        final EditText assessmentDesc = view.findViewById(R.id.editAssessmentDescriptionTF);
        assessmentDesc.setText(RecyclerViewAdapter3.selectedAssessment.getDescription());

        Button editAssessmentSubmitButton = view.findViewById(R.id.editAssessmentSubmitButton);
        editAssessmentSubmitButton.setOnClickListener(v -> {
            MainActivity.DBHelper.updateAssessmentsData(
                    RecyclerViewAdapter3.selectedAssessment.getAssessmentID(),
                    RecyclerViewAdapter2.selectedCourse.getCourseID(),
                    assessmentName.getText().toString(),
                    assessmentDesc.getText().toString(),
                    assessmentGoal.getText().toString()
            );
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        return view;
    }
}
