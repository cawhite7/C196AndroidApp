package com.example.caseywhite_c196;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.text.ParseException;

public class MyReceiver extends BroadcastReceiver {

    static int ID = 0;
    public static String channelID = "Channel";

    @Override
    public void onReceive(Context context, Intent intent) {

        NotificationManager notificationManagerCompat = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelID)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentTitle(intent.getStringExtra("param"))
                .setContentText(intent.getStringExtra("param"))
                .setGroup("test")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        assert notificationManagerCompat != null;
        notificationManagerCompat.notify(ID++, builder.build());

    }

}
