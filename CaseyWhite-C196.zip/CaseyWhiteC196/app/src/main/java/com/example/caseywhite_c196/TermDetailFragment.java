package com.example.caseywhite_c196;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

public class TermDetailFragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_term_detail, container, false);
        TextView selectedTermName = view.findViewById(R.id.selectedTermName);
        TextView selectedTermStartDate = view.findViewById(R.id.selectedStartDate);
        TextView selectedTermEndDate = view.findViewById(R.id.selectedEndDate);
        String startDate = "Start Date: " + RecyclerViewAdapter.selectedTerm.getStartDate();
        String endDate = "End Date: " + RecyclerViewAdapter.selectedTerm.getEndDate();

        selectedTermName.setText(RecyclerViewAdapter.selectedTerm.getName());
        selectedTermStartDate.setText(startDate);
        selectedTermEndDate.setText(endDate);

        Button editTermButton = view.findViewById(R.id.editTermButton);
        editTermButton.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_termDetailFragment_to_editTermFragment));

        Button deleteTermButton = view.findViewById(R.id.deleteTermButton);
        deleteTermButton.setOnClickListener(v -> {
            if (!MainActivity.DBHelper.checkTermDependency(RecyclerViewAdapter.selectedTerm.getTermId())) {
                //Navigation.findNavController(v).navigate(R.id.action_termDetailFragment_to_allTermsFragment);
                requireActivity().getSupportFragmentManager().popBackStack();
                MainActivity.DBHelper.deleteTermsData(String.valueOf(RecyclerViewAdapter.selectedTerm.getTermId()));
            } else {
                Toast.makeText(getActivity(), "Courses exist for this term", Toast.LENGTH_LONG).show();
            }
        });

        Button viewCoursesButton = view.findViewById(R.id.viewCoursesButton);
        viewCoursesButton.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_termDetailFragment_to_termCoursesFragment));

        // Inflate the layout for this fragment
        return view;
    }

}
