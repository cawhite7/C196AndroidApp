package com.example.caseywhite_c196.Skeleton;

import java.util.ArrayList;

public class Assessments {
    private int assessmentID;
    private int courseID;
    private String name;
    private String description;
    private String assessmentGoal;

    private static ArrayList<Assessments> assessmentsList = new ArrayList<>();

    public Assessments(int assessmentID, int courseID, String name, String description, String assessmentGoal) {
        this.assessmentID = assessmentID;
        this.courseID = courseID;
        this.name = name;
        this.description = description;
        this.assessmentGoal = assessmentGoal;
    }

    public int getAssessmentID() { return assessmentID; }
    public void setAssessmentID(int assessmentID) { this.assessmentID = assessmentID; }

    public int getCourseID() { return courseID; }
    public void setCourseID(int courseID) { this.courseID = courseID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getAssessmentGoal() { return assessmentGoal; }
    public void setAssessmentGoal(String assessmentGoal) { this.assessmentGoal = assessmentGoal; }

    public static void addAssessment(Assessments assessment) { assessmentsList.add(assessment); }
    public static ArrayList<Assessments> getAssessmentsList() { return assessmentsList; }
    public static void clearList() { assessmentsList.clear(); }

}
