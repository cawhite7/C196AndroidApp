package com.example.caseywhite_c196;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class EditTermFragment extends Fragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_edit_term, container, false);

        final TextView termName = view.findViewById(R.id.editTermNameTF);
        final TextView startDate = view.findViewById(R.id.editTermStartDateTF);
        final TextView endDate = view.findViewById(R.id.editTermEndDateTF);

        termName.setText(RecyclerViewAdapter.selectedTerm.getName());
        startDate.setText(RecyclerViewAdapter.selectedTerm.getStartDate());
        endDate.setText(RecyclerViewAdapter.selectedTerm.getEndDate());

        Button submitButton = view.findViewById(R.id.editTermSubmitButton);
        submitButton.setOnClickListener(v -> {
            MainActivity.DBHelper.updateTermsData(
                    RecyclerViewAdapter.selectedTerm.getTermId(),
                    termName.getText().toString(),
                    startDate.getText().toString(),
                    endDate.getText().toString(),
                    0
            );
            //Navigation.findNavController(v).navigate(R.id.action_editTermFragment_to_allTermsFragment);
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        return view;
    }
}
