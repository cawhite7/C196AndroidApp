package com.example.caseywhite_c196;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import java.util.Objects;

public class AddTermFragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_add_term, container, false);

        Button submitButton = view.findViewById(R.id.newTermButton);
        final EditText termNameTF = view.findViewById(R.id.termNameTextField);
        final EditText startDateInput = view.findViewById(R.id.startDateTextField);
        final EditText endDateInput = view.findViewById(R.id.endDateTextField);

        submitButton.setOnClickListener(v -> {
            MainActivity.DBHelper.insertTermData(
                    termNameTF.getText().toString(),
                    startDateInput.getText().toString(),
                    endDateInput.getText().toString(),
                    0
            );
            //Terms.clearList();
            //MainActivity.DBHelper.genTermsData();
            //MainActivity.adapter.notifyDataSetChanged();
            //Navigation.findNavController(v).navigate(R.id.action_addTermFragment_to_allTermsFragment);
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        // Inflate the layout for this fragment
        return view;
    }
}
