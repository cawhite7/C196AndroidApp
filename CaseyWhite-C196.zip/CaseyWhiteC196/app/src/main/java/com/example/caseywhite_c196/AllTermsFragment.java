package com.example.caseywhite_c196;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.example.caseywhite_c196.Skeleton.Terms;


public class AllTermsFragment extends Fragment {

    RecyclerView recyclerView;
    public static RecyclerViewAdapter adapter;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_all_terms, container, false);

        recyclerView = view.findViewById(R.id.recycler_view);
        initRecyclerView();

        Button addTermButton = view.findViewById(R.id.addTermButton);
        addTermButton.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_allTermsFragment_to_addTermFragment));

        // Inflate the layout for this fragment
        return view;
    }

    private void initRecyclerView() {
        adapter = new RecyclerViewAdapter();
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Terms.clearList();
        MainActivity.DBHelper.genTermsData();
    }

}
