package com.example.caseywhite_c196;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.caseywhite_c196.Skeleton.Courses;

public class RecyclerViewAdapter2 extends RecyclerView.Adapter<RecyclerViewAdapter2.ViewHolder> {

    public static Courses selectedCourse = null;

    RecyclerViewAdapter2() {
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Courses course = Courses.getCoursesList().get(position);

        String dateComb = course.getStartDate() + " to " + course.getEndDate();

        holder.courseNameTV.setText(course.getName());
        holder.dateTV.setText(dateComb);

        holder.parentLayout.setOnClickListener(v -> {
            selectedCourse = Courses.getCoursesList().get(position);
            Navigation.findNavController(v).navigate(R.id.action_termCoursesFragment_to_courseDetailFragment);
        });

    }

    @Override
    public int getItemCount() {
        return Courses.getCoursesList().size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView courseNameTV;
        TextView dateTV;
        RelativeLayout parentLayout;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            courseNameTV = itemView.findViewById(R.id.termNameTextView);
            dateTV = itemView.findViewById(R.id.dateTextView);
            parentLayout = itemView.findViewById(R.id.recycler_constraint);
        }
    }

}
