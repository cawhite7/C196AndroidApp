package com.example.caseywhite_c196.Skeleton;

import java.util.ArrayList;

public class Courses {
    private int courseID;
    private int termID;
    private String name;
    private String startDate;
    private String endDate;
    private String status;
    private String mentorName;
    private String mentorPhone;
    private String mentorEmail;
    private int alert;
    private String notes;

    private static ArrayList<Courses> coursesList = new ArrayList<>();

    public Courses(
            int courseID,
            int termID,
            String name,
            String startDate,
            String endDate,
            String status,
            String mentorName,
            String mentorPhone,
            String mentorEmail,
            int alert,
            String notes
    ) {
        this.courseID = courseID;
        this.termID = termID;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.mentorName = mentorName;
        this.mentorPhone = mentorPhone;
        this.mentorEmail = mentorEmail;
        this.alert = alert;
        this.notes = notes;
    }

    public int getCourseID() { return courseID; }
    public void setCourseID(int courseID) { this.courseID = courseID; }

    public int getTermID() { return termID; }
    public void setTermID(int termID) { this.termID = termID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMentorName() { return mentorName; }
    public void setMentorName(String mentorName) { this.mentorName = mentorName; }

    public String getMentorPhone() { return mentorPhone; }
    public void setMentorPhone(String mentorPhone) { this.mentorPhone = mentorPhone; }

    public String getMentorEmail() { return mentorEmail; }
    public void setMentorEmail(String mentorEmail) { this.mentorEmail = mentorEmail; }

    public int getAlert() { return alert; }
    public void setAlert(int alert) { this.alert = alert; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public static void addCourse(Courses course) { coursesList.add(course); }
    public static ArrayList<Courses> getCoursesList() { return coursesList; }
    public static void clearList() { coursesList.clear(); }

}
