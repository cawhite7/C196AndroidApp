package com.example.caseywhite_c196;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;

import static java.lang.Integer.parseInt;

public class CourseDetailFragment extends Fragment {

    private TextView status;
    private TextView alerts;
    private static int i = 3000;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_course_detail, container, false);

        TextView courseName = view.findViewById(R.id.assessmentCourseNameTV);
        TextView courseStartDate = view.findViewById(R.id.courseStartDateTV);
        TextView courseEndDate = view.findViewById(R.id.courseEndDateTV);
        TextView mentorNameTV = view.findViewById(R.id.detailCourseMentorName);
        TextView mentorPhoneTV = view.findViewById(R.id.detailCourseMentorPhone);
        TextView mentorEmailTV = view.findViewById(R.id.detailCourseMentorEmail);
        status = view.findViewById(R.id.statusTV);
        alerts = view.findViewById(R.id.alertsTV);
        String startDate = "Start Date: " + MainActivity.DBHelper.getCourseInfo(RecyclerViewAdapter2.selectedCourse.getCourseID(), 1);
        String endDate = "End Date: " + MainActivity.DBHelper.getCourseInfo(RecyclerViewAdapter2.selectedCourse.getCourseID(), 2);
        String statusC = "Status: " + MainActivity.DBHelper.getCourseInfo(RecyclerViewAdapter2.selectedCourse.getCourseID(), 3);
        String alertsC = "Notifications: " + MainActivity.DBHelper.getCourseInfo(RecyclerViewAdapter2.selectedCourse.getCourseID(), 4);
        String mentorName = "Mentor Name: " + MainActivity.DBHelper.getMentorName(RecyclerViewAdapter2.selectedCourse.getCourseID());
        String mentorPhone = "Mentor Phone: " + MainActivity.DBHelper.getMentorPhone(RecyclerViewAdapter2.selectedCourse.getCourseID());
        String mentorEmail = "Mentor Email: " + MainActivity.DBHelper.getMentorEmail(RecyclerViewAdapter2.selectedCourse.getCourseID());


        courseName.setText(MainActivity.DBHelper.getCourseInfo(RecyclerViewAdapter2.selectedCourse.getCourseID(), 0));
        courseStartDate.setText(startDate);
        courseEndDate.setText(endDate);
        status.setText(statusC);
        alerts.setText(alertsC);
        mentorNameTV.setText(mentorName);
        mentorPhoneTV.setText(mentorPhone);
        mentorEmailTV.setText(mentorEmail);

        Button viewNotesButton = view.findViewById(R.id.viewNotesButton);
        viewNotesButton.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_courseDetailFragment_to_notesFragment));

        Button editCourseButton = view.findViewById(R.id.editCourseButton);
        editCourseButton.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_courseDetailFragment_to_editCourseFragment));

        Button deleteCourseButton = view.findViewById(R.id.deleteCourseButton);
        deleteCourseButton.setOnClickListener(v -> {
            if (!MainActivity.DBHelper.checkCourseDependency(RecyclerViewAdapter2.selectedCourse.getCourseID())) {
                //Navigation.findNavController(v).navigate(R.id.action_courseDetailFragment_to_termCoursesFragment);
                requireActivity().getSupportFragmentManager().popBackStack();
                MainActivity.DBHelper.deleteCoursesData(String.valueOf(RecyclerViewAdapter2.selectedCourse.getCourseID()));
            } else {
                Toast.makeText(getActivity(), "Assessments exist for this term", Toast.LENGTH_LONG).show();
            }
        });

        Button assessmentsButton = view.findViewById(R.id.assessmentsButton);
        assessmentsButton.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_courseDetailFragment_to_assessmentsFragment));

        Button alertsChangeButton = view.findViewById(R.id.notificationToggleButton);
        alertsChangeButton.setOnClickListener(v -> {
            String currentAlerts = MainActivity.DBHelper.getCourseInfo(RecyclerViewAdapter2.selectedCourse.getCourseID(), 4);
            if (currentAlerts.equals("On")) {
                MainActivity.DBHelper.updateAlert("Off");
                refreshAlert();
            } else if (currentAlerts.equals("Off")) {
                MainActivity.DBHelper.updateAlert("On");
                refreshAlert();

                notificationStartDate();
                notificationEndDate();
                notificationGoalDate();


            }
        });

        Button statusChangeButton = view.findViewById(R.id.statusChangeButton);
        statusChangeButton.setOnClickListener(v -> {
            String currentStatus = MainActivity.DBHelper.getCourseInfo(RecyclerViewAdapter2.selectedCourse.getCourseID(), 3);
            switch (currentStatus) {
                case "In Progress":
                    MainActivity.DBHelper.updateStatus("Completed");
                    refreshStatus();
                    break;
                case "Dropped":
                    MainActivity.DBHelper.updateStatus("Plan to Take");
                    refreshStatus();
                    break;
                case "Completed":
                    MainActivity.DBHelper.updateStatus("Dropped");
                    refreshStatus();
                    break;
                case "Plan to Take":
                    MainActivity.DBHelper.updateStatus("In Progress");
                    refreshStatus();
                    break;
            }
        });

        // Inflate the layout for this fragment
        return view;
    }


    private void notificationStartDate() {
        String startDate = MainActivity.DBHelper.getCourseStartDate(RecyclerViewAdapter2.selectedCourse.getCourseID());
        Intent intent = new Intent(getActivity(), MyReceiver.class);
        intent.putExtra("param", startDate);
        PendingIntent sender = PendingIntent.getBroadcast(getActivity(), RecyclerViewAdapter2.selectedCourse.getCourseID(), intent, 0);
        AlarmManager alarmManager = (AlarmManager) requireActivity().getSystemService(Context.ALARM_SERVICE);
        Calendar calendar = Calendar.getInstance();
        calendar.set(
                parseInt(startDate.substring(0,4)),
                parseInt(startDate.substring(5,7)) - 1,
                parseInt(startDate.substring(8,10))
        );
        long milliS = calendar.getTimeInMillis();
        assert alarmManager != null;
        alarmManager.set(AlarmManager.RTC_WAKEUP, milliS, sender);
    }

    private void notificationEndDate() {
        String endDate = MainActivity.DBHelper.getCourseEndDate(RecyclerViewAdapter2.selectedCourse.getCourseID());
        Intent intent = new Intent(getActivity(), MyReceiver.class);
        intent.putExtra("param", endDate);
        PendingIntent sender = PendingIntent.getBroadcast(getActivity(), RecyclerViewAdapter2.selectedCourse.getCourseID()+1000, intent, 0);
        AlarmManager alarmManager = (AlarmManager) requireActivity().getSystemService(Context.ALARM_SERVICE);
        Calendar calendar = Calendar.getInstance();
        calendar.set(
                parseInt(endDate.substring(0,4)),
                parseInt(endDate.substring(5,7)) - 1,
                parseInt(endDate.substring(8,10))
        );
        long milliS = calendar.getTimeInMillis();
        assert alarmManager != null;
        alarmManager.set(AlarmManager.RTC_WAKEUP, milliS, sender);
    }

    private void notificationGoalDate() {
        for (String goalDate : MainActivity.DBHelper.getAssessmentGoalsForCourse(RecyclerViewAdapter2.selectedCourse.getCourseID())) {
            Intent intent = new Intent(getActivity(), MyReceiver.class);
            String goalDateMod = "Goal: " + goalDate;
            intent.putExtra("param", goalDateMod);
            PendingIntent sender = PendingIntent.getBroadcast(getActivity(), i++, intent, 0);
            AlarmManager alarmManager = (AlarmManager) requireActivity().getSystemService(Context.ALARM_SERVICE);
            Calendar calendar = Calendar.getInstance();
            calendar.set(
                    parseInt(goalDate.substring(0,4)),
                    parseInt(goalDate.substring(5,7)) - 1,
                    parseInt(goalDate.substring(8,10))
            );
            long milliS = calendar.getTimeInMillis();
            assert alarmManager != null;
            alarmManager.set(AlarmManager.RTC_WAKEUP, milliS, sender);
        }
    }


    private void refreshAlert() {
        String alertsC = "Notifications: " + MainActivity.DBHelper.getCourseInfo(RecyclerViewAdapter2.selectedCourse.getCourseID(), 4);
        alerts.setText(alertsC);
    }

    private void refreshStatus() {
        String statusC = "Status: " + MainActivity.DBHelper.getCourseInfo(RecyclerViewAdapter2.selectedCourse.getCourseID(), 3);
        status.setText(statusC);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Channel";
            String description = "channeldescription";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(MyReceiver.channelID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = requireActivity().getSystemService(NotificationManager.class);
            assert notificationManager != null;
            notificationManager.createNotificationChannel(channel);
        }
    }

}
